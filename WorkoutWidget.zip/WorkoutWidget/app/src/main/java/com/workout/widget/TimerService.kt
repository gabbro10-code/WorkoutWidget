package com.workout.widget

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * A simple background Service that fires a timer tick broadcast every second.
 * The widget receiver handles the countdown logic and UI updates.
 */
class TimerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false

    private val ticker = object : Runnable {
        override fun run() {
            if (!isRunning) return

            // Send tick to widget
            val tickIntent = Intent(this@TimerService, WorkoutWidgetProvider::class.java).apply {
                action = WorkoutWidgetProvider.ACTION_TIMER_TICK
            }
            sendBroadcast(tickIntent)

            // Check if timer is still supposed to run
            if (WorkoutData.isTimerRunning(this@TimerService)) {
                handler.postDelayed(this, 1000)
            } else {
                stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            handler.postDelayed(ticker, 1000)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
