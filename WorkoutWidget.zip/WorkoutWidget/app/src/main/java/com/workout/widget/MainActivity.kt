package com.workout.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ExerciseAdapter
    private lateinit var btnReset: Button
    private lateinit var btnRestoreDefaults: Button
    private lateinit var tvCurrentStep: TextView

    private val exercises = mutableListOf<Exercise>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView       = findViewById(R.id.recycler_exercises)
        btnReset           = findViewById(R.id.btn_reset_workout)
        btnRestoreDefaults = findViewById(R.id.btn_restore_defaults)
        tvCurrentStep      = findViewById(R.id.tv_current_step)

        exercises.addAll(WorkoutData.getExercises(this))

        adapter = ExerciseAdapter(exercises, onDelete = { position ->
            exercises.removeAt(position)
            adapter.notifyItemRemoved(position)
            saveAndUpdate()
        }, onEdit = { position ->
            showEditDialog(position)
        })

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        btnReset.setOnClickListener {
            WorkoutData.setCurrentIndex(this, 0)
            WorkoutData.resetTimer(this)
            updateWidgets()
            refreshCurrentStep()
            Toast.makeText(this, "Workout reset to Step 1", Toast.LENGTH_SHORT).show()
        }

        btnRestoreDefaults.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Restore default workout?")
                .setMessage("This will replace your current exercises.")
                .setPositiveButton("Restore") { _, _ ->
                    exercises.clear()
                    exercises.addAll(WorkoutData.DEFAULT_EXERCISES)
                    adapter.notifyDataSetChanged()
                    saveAndUpdate()
                    Toast.makeText(this, "Default workout restored!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<Button>(R.id.btn_add_exercise).setOnClickListener {
            showAddDialog()
        }

        refreshCurrentStep()
    }

    override fun onResume() {
        super.onResume()
        refreshCurrentStep()
    }

    private fun refreshCurrentStep() {
        val index = WorkoutData.getCurrentIndex(this).coerceIn(0, exercises.size - 1)
        tvCurrentStep.text = "Current Step: ${index + 1} of ${exercises.size} — ${exercises.getOrNull(index)?.name ?: ""}"
    }

    private fun saveAndUpdate() {
        WorkoutData.saveExercises(this, exercises)
        val index = WorkoutData.getCurrentIndex(this).coerceIn(0, exercises.size - 1)
        WorkoutData.setCurrentIndex(this, index)
        WorkoutData.resetTimer(this)
        updateWidgets()
        refreshCurrentStep()
    }

    private fun updateWidgets() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, WorkoutWidgetProvider::class.java))
        for (id in ids) WorkoutWidgetProvider.updateWidget(this, manager, id)
    }

    private fun showAddDialog() {
        showExerciseDialog(null, -1)
    }

    private fun showEditDialog(position: Int) {
        showExerciseDialog(exercises[position], position)
    }

    private fun showExerciseDialog(existing: Exercise?, position: Int) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_exercise, null)
        val etName     = dialogView.findViewById<EditText>(R.id.et_name)
        val etDesc     = dialogView.findViewById<EditText>(R.id.et_description)
        val etDuration = dialogView.findViewById<EditText>(R.id.et_duration)
        val etReps     = dialogView.findViewById<EditText>(R.id.et_reps)

        existing?.let {
            etName.setText(it.name)
            etDesc.setText(it.description)
            etDuration.setText(if (it.durationSeconds > 0) it.durationSeconds.toString() else "")
            etReps.setText(it.reps)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Add Exercise" else "Edit Exercise")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name     = etName.text.toString().trim()
                val desc     = etDesc.text.toString().trim()
                val duration = etDuration.text.toString().toIntOrNull() ?: 0
                val reps     = etReps.text.toString().trim()

                if (name.isEmpty()) {
                    Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val exercise = Exercise(name, desc, duration, reps)
                if (position >= 0) {
                    exercises[position] = exercise
                    adapter.notifyItemChanged(position)
                } else {
                    exercises.add(exercise)
                    adapter.notifyItemInserted(exercises.size - 1)
                }
                saveAndUpdate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class ExerciseAdapter(
    private val items: MutableList<Exercise>,
    private val onDelete: (Int) -> Unit,
    private val onEdit: (Int) -> Unit
) : RecyclerView.Adapter<ExerciseAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView    = view.findViewById(R.id.tv_item_name)
        val tvDetail: TextView  = view.findViewById(R.id.tv_item_detail)
        val btnEdit: ImageButton = view.findViewById(R.id.btn_edit)
        val btnDel: ImageButton  = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_exercise, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ex = items[position]
        holder.tvName.text = "${position + 1}. ${ex.name}"
        holder.tvDetail.text = when {
            ex.durationSeconds > 0 -> "⏱ ${ex.durationSeconds}s"
            ex.reps.isNotEmpty()   -> "🔁 ${ex.reps}"
            else                   -> ex.description
        }
        holder.btnEdit.setOnClickListener { onEdit(holder.adapterPosition) }
        holder.btnDel.setOnClickListener  { onDelete(holder.adapterPosition) }
    }

    override fun getItemCount() = items.size
}
