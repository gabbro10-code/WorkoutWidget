package com.workout.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WorkoutWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_NEXT          = "com.workout.widget.ACTION_NEXT"
        const val ACTION_PREV          = "com.workout.widget.ACTION_PREV"
        const val ACTION_TOGGLE_TIMER  = "com.workout.widget.ACTION_TOGGLE_TIMER"
        const val ACTION_TIMER_TICK    = "com.workout.widget.ACTION_TIMER_TICK"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                android.content.ComponentName(context, WorkoutWidgetProvider::class.java)
            )
            for (id in ids) updateWidget(context, manager, id)
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val exercises = WorkoutData.getExercises(context)
            val index     = WorkoutData.getCurrentIndex(context).coerceIn(0, exercises.size - 1)
            val exercise  = exercises[index]
            val timerSec  = WorkoutData.getTimerSeconds(context)
            val running   = WorkoutData.isTimerRunning(context)

            val views = RemoteViews(context.packageName, R.layout.widget_layout)

            // Step counter
            views.setTextViewText(R.id.tv_step, "Step ${index + 1} of ${exercises.size}")

            // Exercise name & description
            views.setTextViewText(R.id.tv_exercise_name, exercise.name)
            views.setTextViewText(R.id.tv_description, exercise.description)

            // Timer or reps
            if (exercise.durationSeconds > 0) {
                val mins = timerSec / 60
                val secs = timerSec % 60
                views.setTextViewText(R.id.tv_timer, "%d:%02d".format(mins, secs))
                views.setTextViewText(R.id.tv_timer_label,
                    if (running) "⏸ Tap to pause" else "▶ Tap to start")
            } else {
                views.setTextViewText(R.id.tv_timer,
                    if (exercise.reps.isNotEmpty()) exercise.reps else "—")
                views.setTextViewText(R.id.tv_timer_label, "Reps")
            }

            // PREV button
            views.setOnClickPendingIntent(R.id.btn_prev, makePendingIntent(context, ACTION_PREV))

            // NEXT button
            views.setOnClickPendingIntent(R.id.btn_next, makePendingIntent(context, ACTION_NEXT))

            // Timer toggle (tap on timer area)
            views.setOnClickPendingIntent(R.id.ll_timer, makePendingIntent(context, ACTION_TOGGLE_TIMER))

            // Open app on title tap
            val openApp = Intent(context, MainActivity::class.java)
            val openPi = PendingIntent.getActivity(context, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.tv_step, openPi)

            manager.updateAppWidget(widgetId, views)
        }

        private fun makePendingIntent(context: Context, action: String): PendingIntent {
            val intent = Intent(context, WorkoutWidgetProvider::class.java).apply {
                this.action = action
            }
            return PendingIntent.getBroadcast(
                context,
                action.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) updateWidget(context, appWidgetManager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        val exercises = WorkoutData.getExercises(context)
        val index = WorkoutData.getCurrentIndex(context).coerceIn(0, exercises.size - 1)

        when (intent.action) {

            ACTION_NEXT -> {
                val next = (index + 1).coerceAtMost(exercises.size - 1)
                WorkoutData.setCurrentIndex(context, next)
                WorkoutData.setTimerRunning(context, false)
                // Reset timer for next exercise
                WorkoutData.setTimerSeconds(context, exercises[next].durationSeconds)
                stopTimerService(context)
                updateAllWidgets(context)
            }

            ACTION_PREV -> {
                val prev = (index - 1).coerceAtLeast(0)
                WorkoutData.setCurrentIndex(context, prev)
                WorkoutData.setTimerRunning(context, false)
                WorkoutData.setTimerSeconds(context, exercises[prev].durationSeconds)
                stopTimerService(context)
                updateAllWidgets(context)
            }

            ACTION_TOGGLE_TIMER -> {
                val exercise = exercises[index]
                if (exercise.durationSeconds <= 0) return  // no timer for reps-only

                val running = WorkoutData.isTimerRunning(context)
                if (running) {
                    // Pause
                    WorkoutData.setTimerRunning(context, false)
                    stopTimerService(context)
                } else {
                    // Start (reset if at 0)
                    if (WorkoutData.getTimerSeconds(context) <= 0) {
                        WorkoutData.setTimerSeconds(context, exercise.durationSeconds)
                    }
                    WorkoutData.setTimerRunning(context, true)
                    startTimerService(context)
                }
                updateAllWidgets(context)
            }

            ACTION_TIMER_TICK -> {
                val current = WorkoutData.getTimerSeconds(context)
                if (current > 0) {
                    WorkoutData.setTimerSeconds(context, current - 1)
                    if (current - 1 <= 0) {
                        // Timer finished — auto-advance
                        WorkoutData.setTimerRunning(context, false)
                        stopTimerService(context)
                        val next = (index + 1).coerceAtMost(exercises.size - 1)
                        if (next != index) {
                            WorkoutData.setCurrentIndex(context, next)
                            WorkoutData.setTimerSeconds(context, exercises[next].durationSeconds)
                        }
                    }
                }
                updateAllWidgets(context)
            }
        }
    }

    private fun startTimerService(context: Context) {
        val intent = Intent(context, TimerService::class.java)
        context.startService(intent)
    }

    private fun stopTimerService(context: Context) {
        val intent = Intent(context, TimerService::class.java)
        context.stopService(intent)
    }
}
