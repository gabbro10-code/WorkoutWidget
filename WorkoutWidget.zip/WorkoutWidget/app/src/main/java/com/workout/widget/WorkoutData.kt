package com.workout.widget

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Exercise(
    val name: String,
    val description: String,
    val durationSeconds: Int,  // 0 = manual (no timer), >0 = auto-timer
    val reps: String = ""       // e.g. "3x12" — shown if no timer
)

object WorkoutData {

    private const val PREFS_NAME = "workout_prefs"
    private const val KEY_EXERCISES = "exercises"
    private const val KEY_CURRENT_INDEX = "current_index"
    private const val KEY_TIMER_SECONDS = "timer_seconds"
    private const val KEY_TIMER_RUNNING = "timer_running"

    private val gson = Gson()

    // Default workout routine
    val DEFAULT_EXERCISES = listOf(
        Exercise("Warm-Up Jog", "Light jog in place to raise heart rate", 60),
        Exercise("Jumping Jacks", "Full body warm-up, arms and legs wide", 45),
        Exercise("Push-Ups", "Keep core tight, chest to floor", 0, "3 × 12"),
        Exercise("Bodyweight Squats", "Feet shoulder-width, back straight", 0, "3 × 15"),
        Exercise("Plank Hold", "Elbows under shoulders, body straight", 45),
        Exercise("Mountain Climbers", "Drive knees to chest alternately", 40),
        Exercise("Lunges", "Step forward, knee above ankle", 0, "3 × 10 each leg"),
        Exercise("Burpees", "Squat → plank → push-up → jump", 30),
        Exercise("Cool-Down Stretch", "Hold each stretch for 20 seconds", 60),
        Exercise("Workout Complete! 🎉", "Great job! Rest and hydrate.", 0)
    )

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getExercises(context: Context): List<Exercise> {
        val json = prefs(context).getString(KEY_EXERCISES, null) ?: return DEFAULT_EXERCISES
        return try {
            val type = object : TypeToken<List<Exercise>>() {}.type
            gson.fromJson(json, type) ?: DEFAULT_EXERCISES
        } catch (e: Exception) {
            DEFAULT_EXERCISES
        }
    }

    fun saveExercises(context: Context, exercises: List<Exercise>) {
        prefs(context).edit().putString(KEY_EXERCISES, gson.toJson(exercises)).apply()
    }

    fun getCurrentIndex(context: Context): Int =
        prefs(context).getInt(KEY_CURRENT_INDEX, 0)

    fun setCurrentIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_CURRENT_INDEX, index).apply()
    }

    fun getTimerSeconds(context: Context): Int =
        prefs(context).getInt(KEY_TIMER_SECONDS, 0)

    fun setTimerSeconds(context: Context, seconds: Int) {
        prefs(context).edit().putInt(KEY_TIMER_SECONDS, seconds).apply()
    }

    fun isTimerRunning(context: Context): Boolean =
        prefs(context).getBoolean(KEY_TIMER_RUNNING, false)

    fun setTimerRunning(context: Context, running: Boolean) {
        prefs(context).edit().putBoolean(KEY_TIMER_RUNNING, running).apply()
    }

    fun resetTimer(context: Context) {
        val exercises = getExercises(context)
        val index = getCurrentIndex(context).coerceIn(0, exercises.size - 1)
        val duration = exercises[index].durationSeconds
        setTimerSeconds(context, duration)
        setTimerRunning(context, false)
    }
}
