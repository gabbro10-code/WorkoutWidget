# 💪 Workout Widget — Android App

A home screen widget that shows your workout steps one at a time, with a countdown timer and Prev/Next controls.

---

## What it does

- **Home screen widget** showing:
  - Current step (e.g. "Step 3 of 10")
  - Exercise name & description
  - Countdown timer (tap to start/pause) — auto-advances when it hits 0
  - Reps display for strength exercises (e.g. "3 × 12")
  - ◀ PREV and NEXT ▶ buttons
- **Main app** where you can:
  - View all exercises in order
  - Add, edit, or delete exercises
  - Reset the workout back to Step 1
  - Restore the default 10-exercise routine

---

## Default Workout Included

1. Warm-Up Jog — 60s timer
2. Jumping Jacks — 45s timer
3. Push-Ups — 3 × 12 (no timer)
4. Bodyweight Squats — 3 × 15
5. Plank Hold — 45s timer
6. Mountain Climbers — 40s timer
7. Lunges — 3 × 10 each leg
8. Burpees — 30s timer
9. Cool-Down Stretch — 60s timer
10. Workout Complete! 🎉

---

## How to Build the APK

### Step 1 — Install Android Studio
Download from: https://developer.android.com/studio
(Free, works on Windows, Mac, Linux)

### Step 2 — Open the project
1. Launch Android Studio
2. Click **"Open"**
3. Navigate to and select the `WorkoutWidget` folder
4. Wait for Gradle to sync (first time may take 2–3 minutes)

### Step 3 — Add a launcher icon (optional)
- Right-click `app/src/main/res` → New → Image Asset
- Choose a dumbbell or lightning bolt icon
- Or skip — it will use the default Android icon

### Step 4 — Build the APK
Go to menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**

The APK will be at:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Step 5 — Install on your phone

**Option A — USB:**
1. Enable Developer Options on your phone (Settings → About Phone → tap Build Number 7 times)
2. Enable USB Debugging
3. Connect phone via USB
4. In Android Studio: **Run → Run 'app'** (installs directly)

**Option B — File transfer:**
1. Copy `app-debug.apk` to your phone
2. Open it in Files app
3. Allow "Install unknown apps" when prompted
4. Install!

### Step 6 — Add the widget
1. Long-press your home screen
2. Tap **Widgets**
3. Find **"Workout Widget"**
4. Drag it to your home screen
5. Resize as needed (minimum ~3×3 cells recommended)

---

## Customizing Your Workout

Open the **Workout Widget** app:
- Tap **+ Add** to add a new exercise
- Tap the ✏️ pencil icon to edit any exercise
- Tap the 🗑️ trash icon to delete
- Tap **↺ Reset** to restart from Step 1
- Tap **⟳ Defaults** to restore the original routine

For each exercise you can set:
- **Name** (required)
- **Description** — shown in the widget
- **Timer seconds** — enables countdown (leave blank for reps-based)
- **Reps** — shown instead of timer (e.g. "3 × 12")

---

## Project Structure

```
WorkoutWidget/
├── build.gradle                         # Root build config
├── settings.gradle
└── app/
    ├── build.gradle                     # App dependencies
    └── src/main/
        ├── AndroidManifest.xml          # App + widget registration
        ├── java/com/workout/widget/
        │   ├── WorkoutData.kt           # Data models & SharedPrefs storage
        │   ├── WorkoutWidgetProvider.kt # Home screen widget logic
        │   ├── TimerService.kt          # Background 1-second ticker
        │   └── MainActivity.kt          # Workout editor UI
        └── res/
            ├── layout/
            │   ├── widget_layout.xml    # Widget appearance
            │   ├── activity_main.xml    # App main screen
            │   ├── item_exercise.xml    # List row
            │   └── dialog_exercise.xml  # Add/edit dialog
            ├── xml/
            │   └── workout_widget_info.xml  # Widget metadata
            ├── drawable/                # Backgrounds & button styles
            └── values/
                ├── strings.xml
                └── themes.xml
```

---

## Requirements
- Android 8.0+ (API 26+)
- Android Studio Hedgehog or newer
- ~5 minutes to build

---

*Built with Kotlin + AppWidgetProvider + RemoteViews*
